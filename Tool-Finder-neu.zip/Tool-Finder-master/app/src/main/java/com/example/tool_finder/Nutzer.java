package com.example.tool_finder;

public class Nutzer {

private String eMail;
private String passwort;
private String nutzerName;




}

